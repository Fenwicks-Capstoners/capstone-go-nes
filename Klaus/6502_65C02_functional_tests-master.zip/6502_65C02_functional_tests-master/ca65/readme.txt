Klaus Dormann's 6502 tests, edited to build correctly using cc65's assembler
and linker for Windows.

asm_cmp.bat demonstrates the process of assembling, linking and comparing
the resulting binary with the pre-built binaries.

Usage:
  asm_cmp.bat 6502_functional_test